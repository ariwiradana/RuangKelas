package com.example.ruangkelas;

public class DetailAssigmentActivity {
}
